/* ──────────────────────────────────────────────────────────────
   App shell — sidebar + topbar + hash-based router
   ────────────────────────────────────────────────────────────── */
const { useState, useEffect } = React;

const SCREENS = [
  { id: 'home',      label: 'Home',          Icon: IconHome,     badge: '2',  page: HomeScreen,      title: 'Home',            crumb: ['Workspace','Home'] },
  { id: 'path',      label: 'Career path',   Icon: IconPath,                  page: PathScreen,      title: 'Career path',     crumb: ['Workspace','Career path'] },
  { id: 'skills',    label: 'Skills',        Icon: IconSkills,                page: SkillsScreen,    title: 'Skills profile',  crumb: ['Workspace','Skills'] },
  { id: 'aria',      label: 'Aria',          Icon: IconAria,     badge: '·',  page: AriaScreen,      title: 'Conversation',    crumb: ['Workspace','Aria'] },
  { id: 'roadmap',   label: 'Roadmap',       Icon: IconRoadmap,               page: RoadmapScreen,   title: 'Growth roadmap',  crumb: ['Workspace','Roadmap'] },
  { id: 'resume',    label: 'Resume studio', Icon: IconResume,                page: ResumeScreen,    title: 'Resume studio',   crumb: ['Workspace','Resume'] },
  { id: 'shortlist', label: 'Shortlist',     Icon: IconShort,    badge: '12', page: ShortlistScreen, title: 'Role shortlist',  crumb: ['Workspace','Shortlist'] },
  { id: 'journal',   label: 'Journal',       Icon: IconJournal,               page: JournalScreen,   title: 'Career journal',  crumb: ['Workspace','Journal'] },
];

function useHashRoute(){
  const [hash, setHash] = useState(window.location.hash.replace('#','') || 'home');
  useEffect(()=>{
    const h = () => setHash(window.location.hash.replace('#','') || 'home');
    window.addEventListener('hashchange', h);
    return () => window.removeEventListener('hashchange', h);
  },[]);
  return [hash, (id)=>{ window.location.hash = id; setHash(id); }];
}

function Sidebar({active, go}){
  return (
    <aside className="sidebar" data-screen-label="Sidebar">
      <div className="sb-brand">
        <span className="sb-mark"/>
        <span>Kursa</span>
      </div>

      <div className="sb-status">
        <span className="pulse"/>
        <span className="label mono">
          status
          <b>Active search · day 34</b>
        </span>
      </div>

      <div className="sb-section mono">workspace</div>
      <div className="sb-nav">
        {SCREENS.slice(0,4).map(s=>(
          <a key={s.id} className={"sb-item"+(active===s.id?' on':'')} onClick={()=>go(s.id)}>
            <span className="icn"><s.Icon/></span>
            <span>{s.label}</span>
            {s.badge && <span className="badge mono">{s.badge}</span>}
          </a>
        ))}
      </div>

      <div className="sb-section mono">job search</div>
      <div className="sb-nav">
        {SCREENS.slice(4).map(s=>(
          <a key={s.id} className={"sb-item"+(active===s.id?' on':'')} onClick={()=>go(s.id)}>
            <span className="icn"><s.Icon/></span>
            <span>{s.label}</span>
            {s.badge && <span className="badge mono">{s.badge}</span>}
            {s.id==='journal' && <span className="tag mono">draft</span>}
          </a>
        ))}
      </div>

      <div className="sb-spacer"/>

      <div className="sb-search">
        <IconSearch/>
        <span>Quick find…</span>
        <span className="kbd mono">⌘ K</span>
      </div>

      <div className="sb-user">
        <div className="sb-avatar">AM</div>
        <div className="who">
          Alex Morgan
          <span>kursa member · since aug 2025</span>
        </div>
        <span className="chev"><IconChev/></span>
      </div>
    </aside>
  );
}

function Topbar({screen}){
  return (
    <div className="topbar">
      <div className="tb-crumb">
        {screen.crumb.map((c,i)=>(
          <React.Fragment key={i}>
            {i>0 && <span className="sep">/</span>}
            <span className={i===screen.crumb.length-1?'cur':''}>{c}</span>
          </React.Fragment>
        ))}
      </div>
      <div className="tb-spacer"/>
      <div className="tb-meta">
        <span className="dot"/>
        <span>aria · synced 2 min ago</span>
      </div>
      <div className="tb-aria">
        <span className="dot"/>
        <span>Ask Aria</span>
        <span className="k mono">⌘ ↵</span>
      </div>
    </div>
  );
}

function AriaDock({onClick}){
  return (
    <div className="aria-dock" onClick={onClick}>
      <div className="av"/>
      <div className="field">
        <b>Ask Aria.</b> "How did I do on the Linear screen?" · "Compare Notion and Ramp on equity" · "Draft a reply to extend the Notion deadline"
      </div>
      <div className="send mono">
        <span className="k">⌘ ↵</span>
        <span>send</span>
      </div>
    </div>
  );
}

function App(){
  const [active, go] = useHashRoute();
  const screen = SCREENS.find(s=>s.id===active) || SCREENS[0];
  const Page = screen.page;
  const showDock = active === 'home';

  return (
    <div className="app">
      <Sidebar active={active} go={go}/>
      <main className="main" data-screen-label={screen.title}>
        <Topbar screen={screen}/>
        <div className="content">
          <Page/>
        </div>
        {showDock && <AriaDock onClick={()=>go('aria')}/>}
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
