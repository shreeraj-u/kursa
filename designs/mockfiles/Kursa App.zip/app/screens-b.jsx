/* ──────────────────────────────────────────────────────────────
   Screens B — Roadmap, Resume Studio, Shortlist, Journal
   ────────────────────────────────────────────────────────────── */

// ─── ROADMAP ──────────────────────────────────────────────────
function RoadmapScreen(){
  const active = [
    {n:1, h:"Systems-design depth · advanced module", why:"Five of your EM-track JDs name systems-design rigor as the bar. You're at competent — Linear and Ramp need you at confident.", res:"Build · self-paced", badge:"Designing Data-Intensive Apps · ch 7–11", time:{est:"~22h",left:"8h"}, prog:64},
    {n:2, h:"Performance review experience · simulated", why:"The single biggest gap on your readiness map. Aria can run mock reviews using two real-feeling teammate dossiers we've built together.", res:"Practice · with Aria", badge:"6 simulated rounds", time:{est:"~6h",left:"6h"}, prog:0, status:"queued"},
    {n:3, h:"Python re-engagement · ledger rewrite", why:"Keeps a skill you've named as identity-relevant from continuing to fade. Doubles as a fresh portfolio piece for the Linear loop.", res:"Build · weekend project", badge:"github.com/amorgan/ledger-rewrite", time:{est:"~14h",left:"14h"}, prog:0, status:"queued"},
    {n:4, h:"Cross-functional roadmap planning · documented", why:"Closing this turns three currently-borderline EM JDs into solid matches. Sara at Datadog offered to co-author a public writeup.", res:"Write · with co-author", badge:"target: 2,000 words · blog", time:{est:"~10h",left:"10h"}, prog:0, status:"queued"},
    {n:5, h:"Hiring-loop interviewer · training refresh", why:"Your last training was 14 months ago. Most EM JDs explicitly want recent loop experience as a load-bearing signal.", res:"Recertify · Karat or internal", badge:"4h online + 2 mock loops", time:{est:"~8h",left:"8h"}, prog:0, status:"queued"},
  ];
  const done = [
    {n:0, h:"Path commitment workshop", why:"You finished this in week 1. Outcome: EM track, 2-yr horizon. This is the line everything since has bent toward.", res:"Workshop · with Aria", badge:"march 12", date:"mar 12"},
    {n:0, h:"Datadog exit interview · documented learnings", why:"You captured what you actually want from your next team. Re-read this before signing anything.", res:"Reflection · written", badge:"4,100 words", date:"mar 18"},
    {n:0, h:"Resume v1 → v6 · target-driven rewrites", why:"Six tailored versions, all branched from a single canonical profile. Each one explains its own choices.", res:"Resume studio", badge:"6 versions live", date:"mar – apr"},
  ];

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Growth roadmap</h1>
          <p className="lede">A sequence, not a checklist. Each step exists for a reason — and the reason is visible. Reorder anytime by telling Aria what changed.</p>
        </div>
        <div className="actions">
          <span className="chip"><span className="dot" style={{background:'var(--accent)'}}/>5 active · 3 archived</span>
          <button className="btn ghost"><IconDot3/></button>
        </div>
      </div>

      <div className="card">
        <div className="horizon">
          <div className="l mono">if you finish all five</div>
          <h3>You'd land at <b>ready for a first EM seat</b> in approximately <b>8 months</b> — assuming the search lands a senior eng role first.</h3>
          <div className="meta">
            <span>readiness · today <b>61%</b></span>
            <span>readiness · after all 5 <b>89%</b></span>
            <span>est. effort · <b>60 hours</b></span>
          </div>
        </div>

        <div className="rm-section-head">
          <span>active · ordered by strategic impact</span>
          <span>aria reorders weekly · last reordered 4d ago</span>
        </div>

        <div className="rm-list">
          {active.map((it,i)=>(
            <div className="rm-item" key={i}>
              <div className="step mono">
                step
                <span className="n">{String(it.n).padStart(2,'0')}</span>
                {it.status==='queued' ? 'queued' : 'in progress'}
              </div>
              <div>
                <h5>{it.h}</h5>
                <p className="why"><span className="by mono">aria ·</span>{it.why}</p>
                <div className="res">
                  <span style={{color:'var(--mute)',fontFamily:'JetBrains Mono,monospace',fontSize:11}}>resource</span>
                  <span>{it.res}</span>
                  <span className="badge">{it.badge}</span>
                </div>
              </div>
              <div className="side">
                <div className="time mono">
                  <b>{it.time.est}</b>
                  estimated total
                </div>
                <div className="time mono">
                  {it.time.left} remaining
                </div>
                {it.prog > 0 && (
                  <div className="prog">
                    <div className="lbl mono">{it.prog}% complete</div>
                    <div className="bar"><i style={{width:it.prog+'%'}}/></div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="rm-section-head">
          <span>archived · completed</span>
          <span>building a visible history</span>
        </div>

        <div className="rm-list">
          {done.map((it,i)=>(
            <div className="rm-item done" key={i}>
              <div className="step mono">
                <span className="n">✓</span>
                done
              </div>
              <div>
                <h5>{it.h}</h5>
                <p className="why"><span className="by mono">why ·</span>{it.why}</p>
                <div className="res">
                  <span style={{color:'var(--mute)',fontFamily:'JetBrains Mono,monospace',fontSize:11}}>resource</span>
                  <span>{it.res}</span>
                  <span className="badge">{it.badge}</span>
                </div>
              </div>
              <div className="side">
                <div className="time mono">
                  <b>completed</b>
                  {it.date}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── RESUME STUDIO ────────────────────────────────────────────
function ResumeScreen(){
  return (
    <>
      <div className="page-head">
        <div>
          <h1>Resume studio</h1>
          <p className="lede">Pick a target. The document re-ranks. Every line that moves is explained. Nothing leaves your machine until you say so.</p>
        </div>
        <div className="actions">
          <span className="chip live"><span className="dot"/>tailoring · reading JD</span>
          <button className="btn ghost"><IconExport/>export PDF</button>
          <button className="btn"><IconArrow/>send to apply</button>
        </div>
      </div>

      <div className="studio">
        {/* LEFT — document */}
        <div className="studio-left">
          <div className="version-bar">
            <span className="v on">linear_em_v3.pdf</span>
            <span className="v">ramp_sse_v2.pdf</span>
            <span className="v">vercel_staff_v1.pdf</span>
            <span className="v">render_lead_v2.pdf</span>
            <span className="v">notion_se_v4.pdf</span>
            <span className="v">canonical · all-skills.pdf</span>
            <span className="add">+ new version</span>
          </div>
          <div className="doc-pane">
            <div className="name">Alex Morgan</div>
            <div className="contact mono">
              <span>alex@morgan.dev</span><span>415 · 555 · 0142</span><span>sf · ca</span><span>github.com/amorgan</span><span>linkedin.com/in/amorgan</span>
            </div>
            <hr/>

            <div className="sec-h">summary</div>
            <p style={{margin:'0 0 8px',fontSize:13,color:'var(--ink-2)',lineHeight:1.55}}>
              Senior engineer with seven years across payments infrastructure and observability. Recent focus: leading small teams through high-ambiguity rebuilds. Looking for the first management seat on a team I'd be proud to hire onto.
            </p>

            <hr/>
            <div className="sec-h">experience</div>

            <div className="role">
              <div className="r">Senior Software Engineer · Datadog</div>
              <div className="d mono">2022 — 2026</div>
            </div>
            <ul>
              <li className="diff-add">Led a four-engineer rebuild of the metrics intake pod, sustaining <b>2.3M req/s</b> at p99 of <b>41ms</b> — a 3.4× improvement over the prior system.</li>
              <li className="diff-del">Worked on the metrics team and helped with the intake rewrite.</li>
              <li className="diff-add">Ran the EU-region hiring loop — interviewed <b>22</b> candidates, made <b>4</b> hires now all promoted past their starting level.</li>
              <li>Mentored two junior engineers from new-grad through first production launches.</li>
              <li>Owned the on-call rotation for ingestion through three Sev-1 outages, authored the postmortems still cited internally.</li>
            </ul>

            <div className="role">
              <div className="r">Software Engineer · Stripe</div>
              <div className="d mono">2019 — 2022</div>
            </div>
            <ul>
              <li className="diff-add">Built the payouts reconciliation pipeline that cut close-of-day lag from <b>11h</b> to under <b>20m</b>.</li>
              <li>Shipped the dispute-evidence intake redesign — flagship case in the 2021 product launch.</li>
              <li className="diff-del">Worked on the Connect platform and various features.</li>
            </ul>

            <hr/>
            <div className="sec-h">education</div>
            <div className="role">
              <div className="r">B.S. Computer Science · UC Berkeley</div>
              <div className="d mono">2015 — 2019</div>
            </div>
          </div>
        </div>

        {/* RIGHT — controls */}
        <div className="studio-right">
          <div className="studio-rblock">
            <h5>target</h5>
            <div className="target">
              <div className="lg">L</div>
              <div className="meta">
                <div className="t">Engineering Manager · Core</div>
                <div className="s mono">linear.app · sf or remote · senior+</div>
              </div>
              <span className="ch mono">change</span>
            </div>
            <div style={{marginTop:8,fontSize:12,color:'var(--mute)',fontFamily:'JetBrains Mono,monospace'}}>
              · this document re-ranks live as the JD changes
            </div>
          </div>

          <div className="studio-rblock">
            <h5>ats readability</h5>
            <div className="ats">
              <div className="ring"><i>88</i></div>
              <div>
                <div className="t">Strong · readable across 12 trackers</div>
                <div className="s">Two suggestions left — both phrasing, not structure. Score moves to 94 if accepted.</div>
              </div>
            </div>
          </div>

          <div className="studio-rblock">
            <h5>profile coverage</h5>
            <div className="cov">
              <div className="cov-row in"><span className="icon"/><span className="label">Datadog · intake rebuild lead</span><span className="why">on-path</span></div>
              <div className="cov-row in"><span className="icon"/><span className="label">Hiring loop · 22 interviews · 4 hires</span><span className="why">EM signal</span></div>
              <div className="cov-row in"><span className="icon"/><span className="label">Mentorship · 2 junior eng</span><span className="why">EM signal</span></div>
              <div className="cov-row in"><span className="icon"/><span className="label">Stripe · reconciliation rewrite</span><span className="why">scope proof</span></div>
              <div className="cov-row out"><span className="icon"/><span className="label">k8s networking deep-dives</span><span className="why">off-path</span></div>
              <div className="cov-row out"><span className="icon"/><span className="label">Side project · clipsy.app</span><span className="why">unrelated</span></div>
              <div className="cov-row out"><span className="icon"/><span className="label">UC Berkeley clubs · rowing</span><span className="why">cut for space</span></div>
            </div>
          </div>

          <div className="studio-rblock">
            <h5>impact statement · write in plain language</h5>
            <div className="impact-box">
              <div className="raw">"I led the EU-region hiring loop last year, we interviewed about 22 people, made four hires and they're all still here and doing well."</div>
              <div className="arrow mono">↓ aria · rewrite</div>
              <div className="out">Ran the EU-region hiring loop — interviewed <b>22</b> candidates, made <b>4</b> hires now all promoted past their starting level.</div>
              <div className="controls">
                <span className="b accept">accept</span>
                <span className="b">edit</span>
                <span className="b">try another</span>
                <span style={{marginLeft:'auto',color:'var(--mute)'}}>nothing saved until you accept</span>
              </div>
            </div>
          </div>

          <div className="studio-rblock">
            <h5>tailoring · live</h5>
            <div style={{padding:'10px 12px',border:'1px solid var(--line)',borderRadius:9,background:'var(--surface)'}}>
              <div style={{display:'flex',alignItems:'center',gap:8,fontSize:13}}>
                <span style={{width:7,height:7,borderRadius:'50%',background:'var(--accent)',animation:'pulse 1.2s infinite'}}/>
                <span>Reading job description…</span>
                <span className="mono" style={{marginLeft:'auto',fontSize:11,color:'var(--mute)'}}>linear.app/careers/em-core</span>
              </div>
              <div style={{marginTop:10,fontSize:12,color:'var(--mute)',lineHeight:1.5,fontFamily:'JetBrains Mono,monospace'}}>
                <div>· 2 bullets re-ordered · scope ownership ↑</div>
                <div>· 1 phrase shortened to fit emphasis on "small team manage"</div>
                <div>· 3 keywords woven · "high ambiguity", "production-bar", "cross-region"</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

// ─── SHORTLIST ────────────────────────────────────────────────
function ShortlistScreen(){
  const [open, setOpen] = React.useState(0);
  const [filter, setFilter] = React.useState('all');

  const roles = [
    {co:"Linear", letter:"L", title:"Engineering Manager · Core", reason:"On the line you've been walking — a real first EM seat at a product-led company you've named twice as a place you'd be proud to work.", cur:74, strat:92, salary:"~$240k + equity", badge:"stepping-stone", stage:"phone screen tomorrow",
      brief:{
        about:["~80 engineers · series B · ProductLab-funded","Famously high quality bar — 6% interview pass rate","Most EMs come from senior IC at <Linear or peer companies>"],
        keys:["small-team manage","high-ambiguity","production-bar","cross-region"],
        ctx:"Hiring manager Mia Bell — former Stripe Connect. Sara Yoon (your reference) overlapped with her in 2021."
      }
    },
    {co:"Ramp", letter:"R", title:"Senior Engineer · Money Movement", reason:"Direct analog to your Stripe ledger work — the cleanest story to tell in an EM loop within 12 months.", cur:82, strat:88, salary:"~$250k + equity", badge:"applied · 2d ago", stage:"awaiting recruiter reply",
      brief:{
        about:["Series-D · revenue inflecting","Money-movement team is the EM-feeder team","Manager promoted from IC within 14mo last year"],
        keys:["ledger systems","cross-team rollout","on-call mature","SRE-adjacent"],
        ctx:"You applied via warm intro from David Park (Datadog → Ramp 2024)."
      }
    },
    {co:"Vercel", letter:"V", title:"Staff Engineer · Build Platform", reason:"Stepping stone. Closes the systems-design gap without leaving the IC track yet. Buys optionality.", cur:88, strat:71, salary:"~$280k + equity", badge:"stepping-stone", stage:"draft 88% ready",
      brief:{
        about:["Public-facing product team","Staff role with a known TL→EM pipeline","Office-flex · SF, NYC, remote"],
        keys:["large-scale infra","developer experience","performance budgets","cloud-native"],
        ctx:"Apply window closes Monday. Aria has tailored your resume — review before send."
      }
    },
    {co:"Render", letter:"r", title:"Senior Tech Lead · Infrastructure", reason:"Tech-lead role that often promotes to EM within a year. Aligned with your stated 2-year timeline.", cur:86, strat:78, salary:"~$235k + equity", badge:"on-site fri", stage:"panel scheduled · fri",
      brief:{
        about:["Series-B · cloud infra","Smaller team — high-leverage seat","No formal EM path until headcount grows"],
        keys:["infra at scale","cost engineering","SLO ownership"],
        ctx:"You met the founder at the SF infra meetup last September. He flagged you for the role personally."
      }
    },
    {co:"Notion", letter:"N", title:"Senior Engineer · Core Platform", reason:"Strong offer in hand. Worth taking only if you decide the EM track can wait 18 months.", cur:84, strat:62, salary:"$245k + equity", badge:"offer · expires fri", stage:"decision deadline · fri",
      brief:{
        about:["Public · large eng org","Last three EMs promoted from PM, not IC","High autonomy, narrow management ladder"],
        keys:["collaborative editing","performance","API platform"],
        ctx:"Hiring manager: Jordan Reyes — you noted on the call that the rapport was 'fine'."
      }
    },
    {co:"Anthropic", letter:"a", title:"Member of Technical Staff · Infra", reason:"Off-path. Listed because Aria flagged you read three Anthropic posts last week — wants to confirm.", cur:76, strat:38, salary:"$310k + equity", badge:"off-path · double-check", stage:"not applied",
      brief:{
        about:["AI lab · research-engineering hybrid","Mostly IC track; no management seat on this team for 18+ mo"],
        keys:["distributed training","cuda","systems research"],
        ctx:"On your path map this lands in 'detour worth declining'. Aria wants to make sure that's still true."
      }
    },
  ];

  const filtered = filter==='stepping' ? roles.filter(r=>r.badge==='stepping-stone')
                 : filter==='today'    ? roles.filter(r=>r.cur >= 80)
                 : roles;

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Shortlist</h1>
          <p className="lede">Twelve roles, curated. None of them noise. Each card carries the reason it's there — and the reason it might not be.</p>
        </div>
        <div className="actions">
          <span className="chip"><span className="dot"/>{filtered.length} of 12 shown · refreshed 9h ago</span>
          <button className="btn ghost"><IconFilter/>more filters</button>
        </div>
      </div>

      <div className="sl-filter">
        <span>show me</span>
        <span className={"pick"+(filter==='all'?' on':'')} onClick={()=>setFilter('all')}>everything</span>
        <span className={"pick"+(filter==='stepping'?' on':'')} onClick={()=>setFilter('stepping')}>stepping-stone roles</span>
        <span className={"pick"+(filter==='today'?' on':'')} onClick={()=>setFilter('today')}>roles I could take today</span>
        <span className="sep">·</span>
        <span>that match my</span>
        <span className="pick on">eng manager track</span>
        <span className="ct mono">12 curated · 0 generic</span>
      </div>

      {filtered.map((r,i)=>(
        <div key={i} className={"role-card"+(open===i?' expanded':'')} onClick={()=>setOpen(open===i?-1:i)}>
          <div className="role-row">
            <div className="lg" style={{fontStyle:i===3||i===5?'italic':'normal'}}>{r.letter}</div>
            <div className="meta">
              <div className="top">
                <span className="t">{r.title}</span>
                <span className="c">{r.co}</span>
                <span className="badge mono">{r.badge}</span>
              </div>
              <div className="reason">{r.reason}</div>
            </div>
            <div className="fits">
              <div className="fit-pair">
                <span className="lab">current</span>
                <span className="bar"><i style={{width:r.cur+'%'}}/></span>
                <span className="n">{r.cur}</span>
              </div>
              <div className="fit-pair strat">
                <span className="lab">strategic</span>
                <span className="bar"><i style={{width:r.strat+'%'}}/></span>
                <span className="n">{r.strat}</span>
              </div>
            </div>
            <div className="cta">
              <button className="btn" onClick={(e)=>e.stopPropagation()}>{r.badge==='offer · expires fri'?'review offer':'apply with aria'}</button>
              <span className="salary mono">{r.salary}</span>
            </div>
          </div>
          {open===i && (
            <div className="role-brief">
              <div>
                <h6>about · what to know</h6>
                <ul>{r.brief.about.map((a,j)=><li key={j}>{a}</li>)}</ul>
              </div>
              <div>
                <h6>what the role emphasizes</h6>
                <div className="keyw">{r.brief.keys.map((k,j)=><span className="k" key={j}>{k}</span>)}</div>
                <h6 style={{marginTop:14}}>resume suggestions</h6>
                <div className="ctxt">Lead with the Datadog rebuild. Move hiring loop above mentorship. Drop the Stripe Connect line for space.</div>
              </div>
              <div>
                <h6>interview context</h6>
                <div className="ctxt">{r.brief.ctx}</div>
                <h6 style={{marginTop:14}}>your stage</h6>
                <div className="ctxt" style={{color:'var(--accent)',fontFamily:'JetBrains Mono,monospace',fontSize:12}}>{r.stage}</div>
              </div>
            </div>
          )}
        </div>
      ))}
    </>
  );
}

// ─── JOURNAL ──────────────────────────────────────────────────
function JournalScreen(){
  // Sentiment polyline
  const pts = [22,28,35,30,40,38,36,30,18,12,16,24,30,38,42];
  const sw = 720, sh = 80, pad = 8;
  const ptsXY = pts.map((p,i)=>{
    const x = pad + (i/(pts.length-1))*(sw-pad*2);
    const y = pad + (1 - p/55)*(sh-pad*2);
    return [x,y];
  });
  const path = "M "+ptsXY.map(p=>p.join(",")).join(" L ");

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Career journal</h1>
          <p className="lede">A private record of how the work actually feels. Wins, friction, feedback — captured in your words, surfaced when they matter.</p>
        </div>
        <div className="actions">
          <span className="chip"><span className="dot"/>between roles · last entry 2d</span>
          <button className="btn ghost"><IconPlus/>new entry</button>
        </div>
      </div>

      <div className="card" style={{marginBottom:18}}>
        <div className="chead">
          <h3>Engagement — last 14 weeks · across both roles</h3>
          <span className="meta">based on 47 entries</span>
        </div>
        <div style={{padding:'18px 22px'}}>
          <svg viewBox={`0 0 ${sw} ${sh}`} preserveAspectRatio="none" style={{width:'100%',height:80,display:'block'}}>
            <line x1={pad} y1={sh-pad} x2={sw-pad} y2={sh-pad} stroke="#E8E6E0" strokeWidth="0.7"/>
            <path d={path} fill="none" stroke="oklch(0.42 0.04 160)" strokeWidth="1.6" vectorEffect="non-scaling-stroke"/>
            {ptsXY.map((p,i)=>(<circle key={i} cx={p[0]} cy={p[1]} r="2" fill="oklch(0.42 0.04 160)"/>))}
            <line x1={ptsXY[8][0]} y1={pad} x2={ptsXY[8][0]} y2={sh-pad} stroke="#0A0A0A" strokeWidth="0.6" strokeDasharray="2 2"/>
          </svg>
          <div style={{display:'flex',justifyContent:'space-between',marginTop:8,fontFamily:'JetBrains Mono,monospace',fontSize:11,color:'var(--mute)'}}>
            <span>jan</span>
            <span>feb</span>
            <span style={{color:'var(--ink)'}}>layoff · mar 12</span>
            <span>apr</span>
            <span>this week</span>
          </div>
          <div style={{marginTop:14,fontSize:13,color:'var(--mute)',lineHeight:1.5,maxWidth:680}}>
            Your engagement at Datadog drifted down for six weeks before the layoff — a pattern worth noting for next time. Quiet uptick over the last three weeks as the search has gained momentum.
          </div>
        </div>
      </div>

      <div className="journal-grid">
        <div className="card">
          <div className="j-tabs">
            <span className="t on">All entries</span>
            <span className="t">Wins</span>
            <span className="t">Friction</span>
            <span className="t">Feedback</span>
            <span className="t">Reflections</span>
          </div>

          <div className="j-entry agent">
            <div className="when">today · 9:14</div>
            <div className="what"><span className="tag">aria</span>You've mentioned the manager rapport at Notion three times this week, all neutral or below. That's a pattern worth looking at before Friday — not a verdict, but worth surfacing.</div>
          </div>

          <div className="j-entry">
            <div className="when">yest · 18:40</div>
            <div className="what"><span className="tag">friction</span>Notion offer call felt fine but flat. Hiring manager was articulate but didn't ask anything about how I'd build the team. Worth noting.</div>
          </div>

          <div className="j-entry">
            <div className="when">yest · 11:20</div>
            <div className="what"><span className="tag">win</span>Sara from Datadog agreed to be a reference for the Ramp loop. She also offered to co-author the cross-functional planning writeup — that closes one of the top-2 gaps in one move.</div>
          </div>

          <div className="j-entry agent">
            <div className="when">tue</div>
            <div className="what"><span className="tag">aria</span>Two weeks in and you've talked to seven hiring managers — more than the entire 2023 search. Whatever you're doing differently is working.</div>
          </div>

          <div className="j-entry">
            <div className="when">mon · 22:01</div>
            <div className="what"><span className="tag">reflection</span>Six weeks unemployed. The math says I have runway through August but the body is starting to feel the lack of structure. The roadmap is helping more than I expected.</div>
          </div>

          <div className="j-entry">
            <div className="when">sun</div>
            <div className="what"><span className="tag">feedback</span>Linear screener said my answer on "how do you decide what to deprioritize" was the strongest she'd heard this cycle. Filing under EM-relevant signal.</div>
          </div>

          <div className="j-entry agent">
            <div className="when">apr 14</div>
            <div className="what"><span className="tag">aria</span>Three references requested in three days. Your network is working harder than you give it credit for. Worth writing thank-you notes today, not next week.</div>
          </div>
        </div>

        <div style={{display:'flex',flexDirection:'column',gap:18}}>
          <div className="card">
            <div className="chead">
              <h3>Relevance check</h3>
              <span className="meta">your skills · vs market for EM-track</span>
            </div>
            <div style={{padding:'14px 18px'}}>
              <div style={{display:'flex',flexDirection:'column',gap:10}}>
                <RelRow name="systems design" you={70} market={85} />
                <RelRow name="hiring · interviewing" you={80} market={72} />
                <RelRow name="performance reviews" you={20} market={68} />
                <RelRow name="cross-functional planning" you={45} market={75} />
                <RelRow name="public technical voice" you={30} market={48} />
              </div>
              <div style={{marginTop:14,fontSize:12,color:'var(--mute)',lineHeight:1.5,paddingTop:12,borderTop:'1px solid var(--line)'}}>
                Two skills lag the market for EM-track. Both are on your roadmap. <b style={{color:'var(--accent)',fontFamily:'JetBrains Mono,monospace',fontSize:11}}>step 02</b> and <b style={{color:'var(--accent)',fontFamily:'JetBrains Mono,monospace',fontSize:11}}>step 04</b>.
              </div>
            </div>
          </div>

          <div className="card">
            <div className="chead">
              <h3>Wins to surface</h3>
              <span className="meta">auto-populated · for interviews + next review</span>
            </div>
            <div style={{padding:'14px 18px',display:'flex',flexDirection:'column',gap:12}}>
              <div style={{fontSize:13,color:'var(--ink-2)',lineHeight:1.5,paddingLeft:12,borderLeft:'2px solid var(--accent)'}}>
                Led 4-eng rebuild of metrics intake — 3.4× throughput, p99 under 41ms, on time.
              </div>
              <div style={{fontSize:13,color:'var(--ink-2)',lineHeight:1.5,paddingLeft:12,borderLeft:'2px solid var(--accent)'}}>
                22 interviews · 4 hires · all still at company, all promoted past starting level.
              </div>
              <div style={{fontSize:13,color:'var(--ink-2)',lineHeight:1.5,paddingLeft:12,borderLeft:'2px solid var(--accent)'}}>
                Authored three Sev-1 postmortems still cited internally as the template.
              </div>
              <div style={{fontSize:11.5,color:'var(--mute)',fontFamily:'JetBrains Mono,monospace',paddingTop:6}}>· copy all → resume bullets · cover letter · interview prep</div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function RelRow({name, you, market}){
  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',fontSize:12.5,marginBottom:4}}>
        <span style={{color:'var(--ink-2)'}}>{name}</span>
        <span className="mono" style={{fontSize:11,color:'var(--mute)'}}>
          you <b style={{color:you<market?'var(--warn)':'var(--ink)',fontFamily:'Inter,sans-serif',fontSize:12}}>{you}</b>
          {' · '}market <b style={{color:'var(--ink)',fontFamily:'Inter,sans-serif',fontSize:12}}>{market}</b>
        </span>
      </div>
      <div style={{position:'relative',height:6,background:'var(--bg-sub)',borderRadius:1}}>
        <div style={{position:'absolute',left:0,top:0,bottom:0,width:market+'%',background:'var(--line-3)'}}/>
        <div style={{position:'absolute',left:0,top:0,bottom:0,width:you+'%',background:you<market?'var(--warn)':'var(--ink)'}}/>
      </div>
    </div>
  );
}

Object.assign(window, {RoadmapScreen, ResumeScreen, ShortlistScreen, JournalScreen});
