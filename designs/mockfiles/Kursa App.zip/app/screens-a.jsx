/* ──────────────────────────────────────────────────────────────
   Screens A — Home, Path, Skills, Aria
   ────────────────────────────────────────────────────────────── */

// ─── HOME ─────────────────────────────────────────────────────
function HomeScreen(){
  return (
    <>
      <div className="page-head">
        <div>
          <h1>Good morning, Alex.</h1>
          <p className="lede">It's been <b>34 days</b> since you started this search. Two things deserve your attention today — both below.</p>
        </div>
        <div className="actions">
          <span className="chip live"><span className="dot"/>active search · day 34</span>
          <button className="btn ghost"><IconExport/>export weekly digest</button>
        </div>
      </div>

      <div className="home-grid">
        <div className="home-left">

          <div className="card">
            <div className="chead">
              <h3>Career pulse · 12 weeks</h3>
              <span className="meta">growth · visibility · progression</span>
            </div>
            <div className="pulse-row">
              <PulseCell name="growth" tone="steady"
                bars={[0,1,1,2,1,1,2,2,1,2,2,2]} accent={[10,11]}
                note="Two new skills in build. Python recency slipping."/>
              <PulseCell name="visibility" tone="rising"
                bars={[0,0,1,1,2,1,2,2,2,2,2,2]} accent={[10,11]}
                note="Three referrals warmed this month. Profile views ↑."/>
              <PulseCell name="progression" tone="paused"
                bars={[2,2,2,2,1,1,1,1,1,1,1,1]} accent={[]}
                note="Between roles. Pulse picks back up after first signed offer."/>
            </div>
          </div>

          <div className="card">
            <div className="chead">
              <h3>Aria noticed</h3>
              <span className="meta">2 new · 14 dismissed this month</span>
            </div>
            <div className="observe-list">
              <div className="o">
                <div className="marker"/>
                <div>
                  <p>A <b>Senior Engineer, Money Movement</b> role just opened at <b>Ramp</b> — on your target list since March. Strategic fit reads <b>92</b>. Their hiring loop usually closes within 9 days.</p>
                  <div className="meta">surfaced · 18m ago · source: ramp.com/careers</div>
                </div>
                <div className="acts"><a href="#shortlist">open</a> · dismiss</div>
              </div>
              <div className="o">
                <div className="marker"/>
                <div>
                  <p>You haven't touched <b>Python</b> in four months and your roadmap puts a Python project at step 03. Want me to scope a weekend rebuild of the metrics-intake tool?</p>
                  <div className="meta">noticed · this morning · roadmap · step 03</div>
                </div>
                <div className="acts"><a href="#aria">talk through</a> · later</div>
              </div>
              <div className="o">
                <div className="marker"/>
                <div>
                  <p>Linear's hiring page just removed the <b>Engineering Manager · Core</b> posting. Application window likely closing. Your draft is at 88% ready.</p>
                  <div className="meta">noticed · 2h ago · linear.app/careers</div>
                </div>
                <div className="acts"><a href="#resume">finish draft</a> · dismiss</div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="chead">
              <h3>Upcoming · this week</h3>
              <span className="meta">5 items</span>
            </div>
            <div>
              <div className="milestone">
                <div className="when mono"><b>Tomorrow</b>10:00 PT</div>
                <div className="what">Phone screen · Linear EM Core <span className="sub">Aria drafted four questions for you · review before</span></div>
              </div>
              <div className="milestone">
                <div className="when mono"><b>Wed</b>14:00 PT</div>
                <div className="what">Reference call · Sara Yoon → Ramp loop <span className="sub">She's the manager you reported to at Datadog</span></div>
              </div>
              <div className="milestone">
                <div className="when mono"><b>Thu</b>—</div>
                <div className="what">Roadmap milestone · finish systems-design module 3 <span className="sub">Step 04 of 7 · est. 4h remaining</span></div>
              </div>
              <div className="milestone">
                <div className="when mono"><b>Fri</b>—</div>
                <div className="what">Submit Vercel application · window closes Mon <span className="sub">Resume tailored · cover letter drafted</span></div>
              </div>
            </div>
          </div>

        </div>

        <div className="home-right">

          <div className="card">
            <div className="chead">
              <h3>In flight · applications</h3>
              <span className="meta">8 active · 3 closed</span>
            </div>
            <div className="activity">
              <div className="a">
                <span className="when mono">Linear</span>
                <span className="what"><span className="tag">phone screen</span>tomorrow 10:00</span>
                <span className="meta">stage 2 / 5</span>
              </div>
              <div className="a">
                <span className="when mono">Ramp</span>
                <span className="what"><span className="tag">applied</span>2 days ago</span>
                <span className="meta">stage 1 / 4</span>
              </div>
              <div className="a">
                <span className="when mono">Vercel</span>
                <span className="what"><span className="tag">draft</span>resume 88% ready</span>
                <span className="meta">unsent</span>
              </div>
              <div className="a">
                <span className="when mono">Render</span>
                <span className="what"><span className="tag">on-site</span>panel scheduled · fri</span>
                <span className="meta">stage 3 / 4</span>
              </div>
              <div className="a">
                <span className="when mono">Notion</span>
                <span className="what"><span className="tag">offer</span>received · expires fri</span>
                <span className="meta">stage 5 / 5</span>
              </div>
              <div className="a">
                <span className="when mono">Anthropic</span>
                <span className="what"><span className="tag">passed</span>not aligned with path</span>
                <span className="meta">closed</span>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="chead">
              <h3>Recent activity</h3>
              <span className="meta">last 48h</span>
            </div>
            <div className="activity">
              <div className="a">
                <span className="when mono">2h ago</span>
                <span className="what"><span className="tag">check-in</span>weekly Aria sync · 12m</span>
                <span></span>
              </div>
              <div className="a">
                <span className="when mono">yest</span>
                <span className="what"><span className="tag">skill</span>added · k8s networking</span>
                <span></span>
              </div>
              <div className="a">
                <span className="when mono">yest</span>
                <span className="what"><span className="tag">applied</span>Ramp · senior eng</span>
                <span></span>
              </div>
              <div className="a">
                <span className="when mono">mon</span>
                <span className="what"><span className="tag">resume</span>tailored · linear_em_v3</span>
                <span></span>
              </div>
              <div className="a">
                <span className="when mono">sun</span>
                <span className="what"><span className="tag">journal</span>off-cycle reflection · 4 entries</span>
                <span></span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </>
  );
}

function PulseCell({name, tone, bars, accent, note}){
  return (
    <div className="pulse-cell">
      <div className="lbl">
        <span className="n">{name}</span>
        <span className="t mono">{tone}</span>
      </div>
      <div className="pulse-bars">
        {bars.map((v,i)=>{
          const h = [10,20,32][v];
          const isAcc = accent.includes(i);
          return <i key={i} className={isAcc?'acc':(v>0?'on':'')} style={{height:h+'px'}}/>;
        })}
      </div>
      <div className="note">{note}</div>
    </div>
  );
}

// ─── PATH ─────────────────────────────────────────────────────
function PathScreen(){
  const [sel, setSel] = React.useState('em');
  const [hover, setHover] = React.useState(null);

  // Big map
  const now = {x:8, y:50};
  const paths = {
    em: {
      label:"Engineering Manager",
      nodes:[
        {id:'em1', x:24, y:38, t:"Tech lead", yr:"+0.7y"},
        {id:'em2', x:44, y:28, t:"EM · 4 reports", yr:"+1.8y"},
        {id:'em3', x:66, y:22, t:"Senior EM", yr:"+3y"},
        {id:'em4', x:88, y:18, t:"Director, Eng", yr:"+5y"},
      ]
    },
    staff: {
      label:"Staff Engineer",
      nodes:[
        {id:'s1', x:30, y:58, t:"Senior eng II", yr:"+0.8y"},
        {id:'s2', x:50, y:54, t:"Staff eng", yr:"+2.2y"},
        {id:'s3', x:70, y:50, t:"Senior staff", yr:"+4y"},
        {id:'s4', x:90, y:48, t:"Principal", yr:"+6y"},
      ]
    },
    pm: {
      label:"Product",
      nodes:[
        {id:'p1', x:26, y:70, t:"PM rotation", yr:"+1.2y"},
        {id:'p2', x:48, y:74, t:"Senior PM", yr:"+3y"},
        {id:'p3', x:72, y:78, t:"Group PM", yr:"+5y"},
      ]
    },
    indie: {
      label:"Independent",
      nodes:[
        {id:'i1', x:32, y:88, t:"Consulting · part-time", yr:"+1.5y"},
        {id:'i2', x:60, y:92, t:"Full independent", yr:"+3y"},
      ]
    }
  };

  const selectedNode = hover || (paths[sel] && paths[sel].nodes[1]);

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Career path</h1>
          <p className="lede">Five futures plotted from where you stand today. The accented path is the one you've committed to — the others stay visible so you don't forget you can change your mind.</p>
        </div>
        <div className="actions">
          <span className="chip"><span className="dot" style={{background:'var(--accent)'}}/>chosen · eng manager</span>
          <button className="btn ghost"><IconDot3/></button>
        </div>
      </div>

      <div className="path-rail">
        <div className="rail-list">
          {Object.entries(paths).map(([k,p])=>(
            <div key={k} className={"rail-item"+(k===sel?' on':'')} onClick={()=>setSel(k)}>
              <div className="top">
                <span className="pin"/>
                <span className="t">{p.label}</span>
              </div>
              <div className="meta mono">
                <span><b>{p.nodes.length}</b> milestones</span>
                <span>·</span>
                <span>~{p.nodes[p.nodes.length-1].yr.replace('+','')}</span>
              </div>
            </div>
          ))}
          <div className="rail-item" style={{borderStyle:'dashed',color:'var(--mute)'}}>
            <div className="top"><span className="pin" style={{background:'var(--mute-3)'}}/><span className="t" style={{color:'var(--mute)'}}>+ explore another</span></div>
            <div className="meta mono"><span>describe in words to aria</span></div>
          </div>
        </div>

        <div className="card" style={{padding:0}}>
          <div className="map-wrap">
            <svg className="lines" viewBox="0 0 100 100" preserveAspectRatio="none">
              {Object.entries(paths).map(([k,p])=>{
                const chosen = k === sel;
                let prev = now;
                return p.nodes.map((n,i)=>{
                  const line = (
                    <line key={k+i}
                      x1={prev.x} y1={prev.y} x2={n.x} y2={n.y}
                      stroke={chosen ? "oklch(0.42 0.04 160)" : "#CFCCC2"}
                      strokeWidth={chosen ? "0.32" : "0.18"}
                      strokeDasharray={chosen ? "" : "1 0.8"}
                      vectorEffect="non-scaling-stroke"
                    />
                  );
                  prev = n;
                  return line;
                });
              })}
            </svg>
            <div className="map-node now" style={{left:now.x+'%',top:now.y+'%'}}>
              <span className="pin"/> you · apr 2026
            </div>
            {Object.entries(paths).map(([k,p])=>{
              const chosen = k === sel;
              return p.nodes.map(n=>(
                <div key={n.id}
                  onMouseEnter={()=>setHover(n)}
                  onMouseLeave={()=>setHover(null)}
                  className={"map-node "+(chosen?'chosen':'dim')+((selectedNode && selectedNode.id===n.id)?' sel':'')}
                  style={{left:n.x+'%',top:n.y+'%'}}>
                  <span className="pin"/> {n.t} <span className="yr">{n.yr}</span>
                </div>
              ));
            })}
            <div className="map-label chosen" style={{left:'88%', top:'8%'}}>chosen path</div>
            <div className="map-label" style={{left:'88%', top:'58%'}}>+ 3 alternates</div>
          </div>
          <div className="map-axis">
            <span>now · apr 2026</span>
            <span>+1 yr</span>
            <span>+2 yr</span>
            <span>+3 yr</span>
            <span>+5 yr</span>
          </div>
        </div>
      </div>

      {/* Selected node detail */}
      <div className="card" style={{marginTop:18}}>
        <div className="chead">
          <h3>{selectedNode?.t || 'Milestone'}</h3>
          <span className="meta">{paths[sel].label.toLowerCase()} · {selectedNode?.yr || ''} from now</span>
        </div>
        <div className="path-detail">
          <p className="sum">A first management seat on a team of four engineers. This is the milestone you said back in <b style={{color:'var(--ink)'}}>March 2026</b> would make this whole search feel worth it. Most of your gap work and the role shortlist are pointed here.</p>
          <div className="grid3">
            <div className="mini"><div className="k">est. time</div><div className="v">~14 months</div></div>
            <div className="mini"><div className="k">strategic impact</div><div className="v">high · 92</div></div>
            <div className="mini"><div className="k">readiness</div><div className="v">61%</div></div>
          </div>
          <div>
            <div className="k mono" style={{fontSize:11,color:'var(--mute)',marginBottom:8}}>what this requires</div>
            <div className="reqs">
              <div className="row done"><span className="icon"/><span>1 year as tech lead with 2+ engineers reporting in</span></div>
              <div className="row done"><span className="icon"/><span>Trained hiring-loop interviewer · 20+ candidates</span></div>
              <div className="row now"><span className="icon"/><span>Performance review experience (currently building · roadmap step 04)</span></div>
              <div className="row todo"><span className="icon"/><span>Cross-functional roadmap planning · documented</span></div>
              <div className="row todo"><span className="icon"/><span>Budget ownership · headcount + tooling</span></div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

// ─── SKILLS ───────────────────────────────────────────────────
function SkillsScreen(){
  const tech = [
    {n:"TypeScript", w:5, total:5, since:"used now"},
    {n:"React",      w:5, total:5, since:"used now"},
    {n:"Postgres",   w:4, total:5, since:"used now"},
    {n:"Go",         w:3, total:5, since:"2mo ago"},
    {n:"Python",     w:4, total:5, since:"4mo ago", faded:true},
    {n:"Kubernetes", w:3, total:5, since:"1yr ago", faded:true},
    {n:"Rust",       w:1, total:5, since:"never used", faded:true},
  ];
  const lead = [
    {n:"1:1 coaching",     w:4, total:5, since:"3wk ago"},
    {n:"Hiring loops",     w:4, total:5, since:"6wk ago"},
    {n:"Roadmap planning", w:3, total:5, since:"recent"},
    {n:"Conflict mediation", w:2, total:5, since:"2mo ago"},
  ];
  const comms = [
    {n:"Engineering writing", w:4, total:5, since:"used now"},
    {n:"Cross-team presenting", w:3, total:5, since:"6wk ago"},
    {n:"Stakeholder updates", w:3, total:5, since:"recent"},
  ];
  const domain = [
    {n:"Payments · ledgers", w:5, total:5, since:"used now"},
    {n:"Observability", w:4, total:5, since:"6mo ago", faded:true},
    {n:"Distributed systems", w:4, total:5, since:"used now"},
  ];
  const building = [
    {n:"Systems design (advanced)", w:3, total:5, label:"in progress · 60%"},
    {n:"Engineering management", w:1, total:5, label:"just started · 15%"},
  ];
  const gaps = [
    {n:"Performance review experience", why:"Required on the EM ladder at most companies. Currently the single biggest gap to your chosen path.", impact:"high"},
    {n:"Cross-functional planning", why:"Surfaces in 14 of 18 EM JDs you've matched. Internal lateral could close this in 3 months.", impact:"high"},
    {n:"Budget ownership", why:"Differentiator at Series-C and beyond. Not blocking the first EM seat, but blocks the second.", impact:"medium"},
    {n:"Public technical voice", why:"You said this matters for the long game. Last post was 11 months ago.", impact:"medium"},
  ];

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Skills profile</h1>
          <p className="lede">A portrait of you, not a checklist. Skills you use stay sharp. Skills you don't use fade. Gaps are ranked by what the path actually needs.</p>
        </div>
        <div className="actions">
          <span className="chip"><span className="dot"/>last refreshed · 2 days ago</span>
          <button className="btn ghost"><IconPlus/>add via aria</button>
        </div>
      </div>

      <div className="skills-grid">
        <div className="card">
          <div className="chead">
            <h3>What you bring</h3>
            <span className="meta">7 active · 4 fading · 2 building</span>
          </div>
          <SkillCatBlock name="technical" m="7 of 32 mapped" items={tech} />
          <SkillCatBlock name="leadership" m="4 of 9 mapped" items={lead} />
          <SkillCatBlock name="communication" m="3 of 6 mapped" items={comms} />
          <SkillCatBlock name="domain" m="3 of 5 mapped" items={domain} />
          <SkillCatBlock name="being built" m="2 active" items={building} build />
        </div>

        <div style={{display:'flex',flexDirection:'column',gap:18}}>
          <div className="card">
            <div className="chead">
              <h3>Gap to chosen path</h3>
              <span className="meta">eng manager · ranked by impact</span>
            </div>
            <div className="gap-card">
              <div className="sub">The four gaps below cover <b style={{color:'var(--ink)',fontFamily:'Inter,sans-serif'}}>71%</b> of the EM-readiness signal in your matched JDs. Closing the top two would shift readiness from 61% to roughly 79%.</div>
              {gaps.map((g,i)=>(
                <div className="item" key={i}>
                  <span className="rank mono">{String(i+1).padStart(2,'0')}</span>
                  <div>
                    <div className="n">{g.n}</div>
                    <div className="why">{g.why}</div>
                  </div>
                  <span className="impact mono">· {g.impact}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="chead">
              <h3>Add a skill</h3>
              <span className="meta">via conversation, not a form</span>
            </div>
            <div className="add-skill" style={{margin:16}}>
              <div className="l mono">recent example · added saturday</div>
              <div className="ex">"Aria, I ran the search-rewrite project at Datadog last quarter — owned design through rollout."</div>
              <div style={{marginTop:10,fontSize:12,color:'var(--mute)',fontFamily:'JetBrains Mono,monospace'}}>
                → mapped to <b style={{color:'var(--accent)'}}>systems design · advanced</b> + <b style={{color:'var(--accent)'}}>technical leadership</b>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function SkillCatBlock({name,m,items,build}){
  return (
    <div className="skill-cat-block">
      <div className="hd">
        <span className="n">{name}</span>
        <span className="m mono">{m}</span>
      </div>
      {items.map((s,i)=>(
        <div className="skill-row" key={i}>
          <span className={"name"+(s.faded?' faded':'')}>{s.n}</span>
          <span className="bar">
            {Array.from({length:s.total}).map((_,j)=>{
              const filled = j < s.w;
              const cls = !filled ? 'off' : (build ? 'build' : (s.faded ? 'faded' : ''));
              return <i key={j} className={cls}/>;
            })}
          </span>
          <span className="since mono">{s.since || s.label}</span>
        </div>
      ))}
    </div>
  );
}

// ─── ARIA ─────────────────────────────────────────────────────
function AriaScreen(){
  const threads = [
    {sec:"this week"},
    {t:"Notion offer — should I take it?", m:"2h ago · live"},
    {t:"Linear EM screen prep — questions", m:"yest"},
    {t:"Python re-engagement plan", m:"3d ago"},
    {sec:"this month"},
    {t:"Ramp shortlist · reasoning", m:"apr 18"},
    {t:"Coaching feedback from Sara", m:"apr 14"},
    {t:"What if I took the contract route", m:"apr 09"},
    {sec:"older"},
    {t:"Layoff debrief — what mattered", m:"mar 28"},
    {t:"Initial path workshop", m:"mar 12"},
  ];
  return (
    <>
      <div className="page-head" style={{marginBottom:18}}>
        <div>
          <h1>Aria</h1>
          <p className="lede">142 days of context. Pick up where you left off, or start a new thread.</p>
        </div>
        <div className="actions">
          <span className="chip accent"><span className="dot"/>memory · on · 4,318 facts</span>
          <button className="btn ghost"><IconPlus/>new thread</button>
        </div>
      </div>

      <div className="aria-layout">
        <div className="thread-list">
          {threads.map((th,i)=>{
            if(th.sec) return <div key={i} className="thread-section mono">{th.sec}</div>;
            return (
              <div key={i} className={"thread-item"+(i===1?' on':'')}>
                <div className="t">{th.t}</div>
                <div className="m mono">{th.m}</div>
              </div>
            );
          })}
        </div>

        <div className="chat">
          <div className="chat-head">
            <div className="who">
              <div className="av"></div>
              <div>
                <h4>Notion offer — should I take it?</h4>
                <span className="sub mono">thread · started 2h ago · 7 messages</span>
              </div>
            </div>
            <div className="actions" style={{display:'flex',gap:8}}>
              <span className="chip"><span className="dot"/>context: full</span>
              <button className="btn ghost"><IconDot3/></button>
            </div>
          </div>

          <div className="chat-scroll">
            <div className="day-sep mono"><span>today · 14:01 PT</span></div>

            <div className="msg user">
              <div className="who mono">alex · 14:01</div>
              <div className="body">Got the Notion offer. Senior Eng, 245 base, 1.4M equity over 4. Decision deadline Friday. Worth taking?</div>
            </div>

            <div className="msg aria">
              <div className="who"><span className="av"/><span>aria · 14:02</span></div>
              <div className="body">
                Strong offer. The number is competitive against your last comp at Datadog and slightly ahead of where Linear is likely to land. But you've been clear about two things since we started in March — you want a path to engineering management, and you want the team you join to be one where you'd report to a manager you respect.
                <br/><br/>
                Notion solves the first only indirectly. It's a senior IC seat on a team that promotes laterally, not vertically — their last three EMs came from PM, not eng. The second one I can't read for you, but I noticed you haven't mentioned the hiring manager once across our seven messages today.
                <div className="recall mono">
                  · pulled from: <span style={{color:'var(--accent)'}}>path commitment</span> · march 12<br/>
                  · pulled from: <span style={{color:'var(--accent)'}}>notion research</span> · apr 04<br/>
                  · cross-checked with: <span style={{color:'var(--accent)'}}>3 EM transitions</span> in your network
                </div>
              </div>
            </div>

            <div className="msg user">
              <div className="who mono">alex · 14:04</div>
              <div className="body">Fair. The manager seemed fine on the call. Not great, not bad. But the work would be interesting and I'm tired of being unemployed.</div>
            </div>

            <div className="msg aria">
              <div className="who"><span className="av"/><span>aria · 14:05</span></div>
              <div className="body">
                "Tired of being unemployed" is real, and it deserves more weight than a model can give it. So let me ask the version of the question that's actually decidable: <b>if Linear comes back with an EM offer next week, would you regret signing Notion on Friday?</b>
                <br/><br/>
                You don't have to answer me. Just sit with it before you reply to Notion. If the answer is no, sign it. If it's yes, here's a draft asking Notion for one more week.
              </div>
            </div>
          </div>

          <div className="chat-prompts">
            <span className="sg">Show me the draft to ask for an extension</span>
            <span className="sg">Compare Notion vs Linear on equity, honestly</span>
            <span className="sg">What did I tell you in March about managers I respect?</span>
          </div>

          <div className="chat-input">
            <div className="av"/>
            <div className="field">Continue the thread…</div>
            <div className="actions">
              <span className="k">↵ to send</span>
              <span className="send">Send</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

Object.assign(window, {HomeScreen, PathScreen, SkillsScreen, AriaScreen});
