/* Sidebar nav icons — 16px stroke icons */
const Icon = ({d, sw=1.5}) => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    {d}
  </svg>
);

const IconHome     = () => <Icon d={<><path d="M2.5 7.5L8 3l5.5 4.5"/><path d="M3.5 7v6h9V7"/></>} />;
const IconPath     = () => <Icon d={<><circle cx="3.5" cy="8" r="1.4"/><circle cx="12.5" cy="4" r="1.4"/><circle cx="12.5" cy="12" r="1.4"/><path d="M4.7 7.3L11.3 4.7"/><path d="M4.7 8.7L11.3 11.3"/></>} />;
const IconSkills   = () => <Icon d={<><path d="M2.5 13V8"/><path d="M6 13V5"/><path d="M9.5 13V9"/><path d="M13 13V3"/></>} />;
const IconAria     = () => <Icon d={<><path d="M2.5 7.5C2.5 5 4.5 3.5 8 3.5s5.5 1.5 5.5 4-2 4-5.5 4c-.7 0-1.4-.07-2-.2L3 12.5l.7-2A4 4 0 0 1 2.5 7.5z"/></>} />;
const IconRoadmap  = () => <Icon d={<><path d="M3 3.5h7M6.5 7.5h7M3 11.5h7"/><circle cx="11.5" cy="3.5" r="1.2"/><circle cx="4.5" cy="7.5" r="1.2"/><circle cx="11.5" cy="11.5" r="1.2"/></>} />;
const IconResume   = () => <Icon d={<><rect x="3" y="2.5" width="10" height="11" rx="1"/><path d="M5.5 5.5h5M5.5 8h5M5.5 10.5h3"/></>} />;
const IconShort    = () => <Icon d={<><rect x="2.5" y="4" width="11" height="8" rx="1"/><path d="M6 4V2.5h4V4"/><path d="M2.5 7.5h11"/></>} />;
const IconJournal  = () => <Icon d={<><path d="M3 2.5h8a1 1 0 0 1 1 1v10l-2.5-1.5-2.5 1.5-2.5-1.5-2.5 1.5v-10a1 1 0 0 1 1-1z"/></>} />;
const IconChev     = () => <Icon d={<><path d="M6 4l3 4-3 4"/></>} />;
const IconSearch   = () => <Icon d={<><circle cx="7" cy="7" r="3.5"/><path d="M10 10l3 3"/></>} />;
const IconArrow    = () => <Icon d={<><path d="M3 8h10M9 4l4 4-4 4"/></>} />;
const IconPlus     = () => <Icon d={<><path d="M8 3.5v9M3.5 8h9"/></>} />;
const IconFilter   = () => <Icon d={<><path d="M2.5 4h11M4.5 8h7M6.5 12h3"/></>} />;
const IconDot3     = () => <Icon d={<><circle cx="4" cy="8" r=".8" fill="currentColor"/><circle cx="8" cy="8" r=".8" fill="currentColor"/><circle cx="12" cy="8" r=".8" fill="currentColor"/></>} sw={0}/>;
const IconExport   = () => <Icon d={<><path d="M8 2.5v7M5 5.5l3-3 3 3"/><path d="M3 10v3h10v-3"/></>} />;

Object.assign(window, {
  Icon, IconHome, IconPath, IconSkills, IconAria, IconRoadmap, IconResume,
  IconShort, IconJournal, IconChev, IconSearch, IconArrow, IconPlus, IconFilter, IconDot3, IconExport
});
